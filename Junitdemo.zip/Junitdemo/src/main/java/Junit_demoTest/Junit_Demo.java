package Junit_demoTest;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Junit_Demo {
    public static void main(String[] args) throws InterruptedException {
        System.setProperty("webdriver.chrome.driver","D:/QMDownload/Driver/chromedriverV80.exe");
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.baidu.com/");
        System.out.println("Home Title："+driver.getTitle());
        driver.quit();

        Thread.sleep(10000);
    }
}

