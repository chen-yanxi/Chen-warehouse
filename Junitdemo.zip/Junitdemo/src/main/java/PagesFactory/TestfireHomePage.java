package PagesFactory;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class TestfireHomePage {

    WebDriver driver;
    @FindBy(xpath = "//*[@id=\"_ctl0__ctl0_Content_Main_promo\"]/table/tbody/tr[1]/td/h2")
    WebElement HomePageCongratulations;

    public TestfireHomePage(WebDriver driver){
        this.driver = driver;
        //This initElements method will create  all WebElements
        PageFactory.initElements(driver,this);
    }

    //Get the Congratulations from Home Page
    public String getHomePageCongratulations(){
        return HomePageCongratulations.getText();
    }

}
