package PagesFactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class TestfireLogin {
    WebDriver driver;
    @FindBy(name = "Username")
    WebElement TestfireUserName;

    @FindBy(name = "Password")
    WebElement TestfirePassWord;

    @FindBy(className = "barone")
    WebElement TitleText;

    @FindBy(name = "btnLogin")
    WebElement Login;

    public TestfireLogin(WebDriver driver){
        this.driver = driver ;
        //This initElements method will create  all WebElements
        PageFactory.initElements(driver,this);
    }

    //Set Username in textbox
    public void setUserName(String strUserName) {
        TestfireUserName.sendKeys(strUserName);
    }
    //Set Password in textbox
    public void setPassWord(String strPassWord){
        TestfirePassWord.sendKeys(strPassWord);
    }
    //Click on login button
    public void clickLogin(){
        Login.click();
    }
    //Get the title of LoginPage
    public String getLoginTitle(){
        return TitleText.getText();
    }

    public void LoginTotestfire(String strUserName,String strPassWord){
        //Fill user name
        this.setUserName(strUserName);
        //Fill password
        this.setPassWord(strPassWord);
        //Click Login button
        this.clickLogin();
    }
}
