package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class TestfireHomePage {

    WebDriver driver;
    By HomePageCongratulations = By.xpath("//*[@id=\"_ctl0__ctl0_Content_Main_promo\"]/table/tbody/tr[1]/td/h2");

    public TestfireHomePage(WebDriver driver){
        this.driver = driver;
    }

    //Get the Congratulations from Home Page
    public String getHomePageCongratulations(){
        return driver.findElement(HomePageCongratulations).getText();
    }
}
