package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class TestfireLogin {
    WebDriver driver;
    By TestfireUserName = By.name("Username");
    By TestfirePassWord =By.name("Password");
    By TitleText = By.className("barone");
    By Login =By.name("btnLogin");

    public TestfireLogin(WebDriver driver){
        this.driver = driver ;
    }

    //Set Username in textbox
    public void setUserName(String strUserName) {
        driver.findElement(TestfireUserName).sendKeys(strUserName);
    }
    //Set Password in textbox
    public void setPassWord(String strPassWord){
        driver.findElement(TestfirePassWord).sendKeys(strPassWord);
    }
    //Click on login button
    public void clickLogin(){
        driver.findElement(Login).click();
    }
    //Get the title of LoginPage
    public String getLoginTitle(){
        return driver.findElement(TitleText).getText();
    }

    public void LoginTotestfire(String strUserName,String strPassWord){
        //Fill user name
        this.setUserName(strUserName);
        //Fill password
        this.setPassWord(strPassWord);
        //Click Login button
        this.clickLogin();
    }
}
