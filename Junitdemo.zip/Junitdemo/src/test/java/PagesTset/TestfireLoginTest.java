package PagesTset;

import Pages.TestfireHomePage;
import Pages.TestfireLogin;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.firefox.FirefoxDriver;
//import org.openqa.selenium.firefox.FirefoxOptions;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

public class TestfireLoginTest {
    WebDriver driver ;
    TestfireLogin objLogin;
    TestfireHomePage objHomePage;

    @BeforeTest
    public void setup(){
        //FirefoxOptions firefoxOptions= new FirefoxOptions();
        //firefoxOptions.setBinary("D:\\QMDownload\\FireFox\\Mozilla Firefox/firefox.exe");
        //FirefoxDriver driver = new FirefoxDriver(firefoxOptions);

        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.get("http://www.testfire.net/login.jsp");
    }



    @Test(priority=0)
    public void test_Home_Page_Appear_Correct(){
        //Create Login Page object
        objLogin = new TestfireLogin(driver);
        //Verify login page title
        String loginPageTitle = objLogin.getLoginTitle();
        System.out.println(loginPageTitle);
        Assert.assertTrue(loginPageTitle.toLowerCase().contains("guru99 bank"));
        //login to application
        objLogin.LoginTotestfire("admin", "admin");
        // go the next page
        objHomePage = new TestfireHomePage(driver);
        //Verify home page
        Assert.assertTrue(objHomePage.getHomePageCongratulations().toLowerCase().contains("Congratulations!"));
    }

}
