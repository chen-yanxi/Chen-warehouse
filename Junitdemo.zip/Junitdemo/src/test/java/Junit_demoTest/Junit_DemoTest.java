package Junit_demoTest;

import org.junit.Test;
import org.junit.Before;
import org.junit.After;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

/**
 * Junit_Demo Tester.
 *
 * @author <Authors name>
 * @since <pre>4�� 19, 2020</pre>
 * @version 1.0
 */

public class Junit_DemoTest {
    WebDriver driver;
        @Before
        public void before()  {
            System.setProperty("webdriver.chrome.driver", "D:/QMDownload/Driver/chromedriverV80.0.3987.106.exe");
            driver = new ChromeDriver();
        }

        /**
         *
         * Method: main(String[] args)
         *
         */
        //TODO: Test goes here...
        @Test
        public void testMain1() {
            driver.get("https://www.baidu.com/");
            WebElement element = driver.findElement(By.id("kw"));
            element.sendKeys("九江学院");
            element.submit();
        }
        @Test
        public void testMain2() {
            driver.get("https://www.baidu.com/");
            WebElement element = driver.findElement(By.cssSelector("#kw"));
            element.sendKeys("自动化测试");
            element.submit();
        }
        @Test
        public void testMain3()  {
            driver.get("http://dl.webxgame.com/");
            String text = driver.findElement(By.partialLinkText("忘记密码？")).getText();
            assertThat("忘记密码？", is(text));
    }



    @After
        public void after() throws Exception {
            Thread.sleep(3000);
            driver.quit();
        }



}
